import os
import json
import logging
from datetime import datetime
from html import escape
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    ConversationHandler,
    ContextTypes,
    filters
)

# Настройки
TOKEN = "here token bot(fatherbot)"
DOSSIER_FOLDER = "dossiers"
DATA_FILE = "user_data.json"

# Этапы диалога
(
    FULL_NAME, BIRTH_DATE, BIRTH_PLACE, 
    ADDRESS, REGION, COUNTRY,
    EDUCATION, SCHOOL, GRADUATION_YEAR,
    PHONE, EMAIL, SOCIAL_MEDIA,
    PARENTS, FRIENDS, NOTES
) = range(15)

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

def ensure_folders():
    """Создает необходимые папки"""
    os.makedirs(DOSSIER_FOLDER, exist_ok=True)

def create_keyboard(skip_button=True):
    """Создает клавиатуру с кнопкой пропуска"""
    if skip_button:
        keyboard = [[KeyboardButton("⏭️ Пропустить")]]
        return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True)
    return ReplyKeyboardMarkup([[KeyboardButton("⏭️ Пропустить")]], resize_keyboard=True, one_time_keyboard=True)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Начало диалога"""
    user = update.effective_user
    
    welcome_message = """
🔥 *Добро пожаловать в TMD DOSSIER* 🔥

Я помогу тебе создать OSINT досье.

📋 *Собираемые данные:*
 Личная информация
 Контактные данные  
 Адрес проживания
 Образование
 Социальные связи
 И многое другое

🎨 *Результат:* HTML файл, лучше чем мальтего)

⚡ *Не знаете, что написать в поле?* — используйте кнопку «Пропустить» внизу

Начнем! Введите ФИО (или нажмите «Пропустить»):
    """
    
    await update.message.reply_text(
        welcome_message,
        parse_mode='Markdown',
        reply_markup=create_keyboard()
    )
    return FULL_NAME

async def handle_full_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка ФИО"""
    text = update.message.text
    
    if text == "⏭️ Пропустить":
        context.user_data['full_name'] = None
        message = "👤 ФИО пропущено\n\n📅 *Дата рождения:*\n(Например: 15.05.2000 или 15 мая 2000)"
    else:
        context.user_data['full_name'] = text
        message = f"✅ ФИО сохранено: *{text}*\n\n📅 *Дата рождения:*\n(Например: 15.05.2000 или 15 мая 2000)"
    
    await update.message.reply_text(
        message,
        parse_mode='Markdown',
        reply_markup=create_keyboard()
    )
    return BIRTH_DATE

async def handle_birth_date(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка даты рождения"""
    text = update.message.text
    
    if text == "⏭️ Пропустить":
        context.user_data['birth_date'] = None
        message = "🎂 Дата рождения пропущена\n\n📍 *Место рождения:*\n(Город, населенный пункт)"
    else:
        context.user_data['birth_date'] = text
        message = f"✅ Дата рождения сохранена\n\n📍 *Место рождения:*\n(Город, населенный пункт)"
    
    await update.message.reply_text(
        message,
        parse_mode='Markdown',
        reply_markup=create_keyboard()
    )
    return BIRTH_PLACE

async def handle_birth_place(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка места рождения"""
    text = update.message.text
    
    if text == "⏭️ Пропустить":
        context.user_data['birth_place'] = None
        message = "🏠 Место рождения пропущено\n\n🏡 *Адрес проживания:*\n(Улица, дом, квартира)"
    else:
        context.user_data['birth_place'] = text
        message = f"✅ Место рождения сохранено\n\n🏡 *Адрес проживания:*\n(Улица, дом, квартира)"
    
    await update.message.reply_text(
        message,
        parse_mode='Markdown',
        reply_markup=create_keyboard()
    )
    return ADDRESS

async def handle_address(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка адреса"""
    text = update.message.text
    
    if text == "⏭️ Пропустить":
        context.user_data['address'] = None
        message = "📍 Адрес проживания пропущен\n\n🗺️ *Регион/Область:*\n(Московская область, Краснодарский край и т.д.)"
    else:
        context.user_data['address'] = text
        message = f"✅ Адрес сохранен\n\n🗺️ *Регион/Область:*\n(Московская область, Краснодарский край и т.д.)"
    
    await update.message.reply_text(
        message,
        parse_mode='Markdown',
        reply_markup=create_keyboard()
    )
    return REGION

async def handle_region(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка региона"""
    text = update.message.text
    
    if text == "⏭️ Пропустить":
        context.user_data['region'] = None
        message = "🌍 Регион пропущен\n\n🌐 *Страна:*\n(Россия, Украина, Казахстан и т.д.)"
    else:
        context.user_data['region'] = text
        message = f"✅ Регион сохранен\n\n🌐 *Страна:*\n(Россия, Украина, Казахстан и т.д.)"
    
    await update.message.reply_text(
        message,
        parse_mode='Markdown',
        reply_markup=create_keyboard()
    )
    return COUNTRY

async def handle_country(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка страны"""
    text = update.message.text
    
    if text == "⏭️ Пропустить":
        context.user_data['country'] = None
        message = "🌏 Страна пропущена\n\n🎓 *Образование:*\n(Среднее, Высшее, Среднее специальное)"
    else:
        context.user_data['country'] = text
        message = f"✅ Страна сохранена\n\n🎓 *Образование:*\n(Среднее, Высшее, Среднее специальное)"
    
    await update.message.reply_text(
        message,
        parse_mode='Markdown',
        reply_markup=create_keyboard()
    )
    return EDUCATION

async def handle_education(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка образования"""
    text = update.message.text
    
    if text == "⏭️ Пропустить":
        context.user_data['education'] = None
        message = "📚 Образование пропущено\n\n🏫 *Учебное заведение:*\n(Школа, Колледж, ВУЗ)"
    else:
        context.user_data['education'] = text
        message = f"✅ Образование сохранено\n\n🏫 *Учебное заведение:*\n(Школа, Колледж, ВУЗ)"
    
    await update.message.reply_text(
        message,
        parse_mode='Markdown',
        reply_markup=create_keyboard()
    )
    return SCHOOL

async def handle_school(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка учебного заведения"""
    text = update.message.text
    
    if text == "⏭️ Пропустить":
        context.user_data['school'] = None
        message = "🎓 Учебное заведение пропущено\n\n📅 *Год окончания:*\n(Например: 2020)"
    else:
        context.user_data['school'] = text
        message = f"✅ Учебное заведение сохранено\n\n📅 *Год окончания:*\n(Например: 2020)"
    
    await update.message.reply_text(
        message,
        parse_mode='Markdown',
        reply_markup=create_keyboard()
    )
    return GRADUATION_YEAR

async def handle_graduation_year(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка года окончания"""
    text = update.message.text
    
    if text == "⏭️ Пропустить":
        context.user_data['graduation_year'] = None
        message = "📆 Год окончания пропущен\n\n📱 *Номер телефона:*\n(В любом формате)"
    else:
        context.user_data['graduation_year'] = text
        message = f"✅ Год окончания сохранен\n\n📱 *Номер телефона:*\n(В любом формате)"
    
    await update.message.reply_text(
        message,
        parse_mode='Markdown',
        reply_markup=create_keyboard()
    )
    return PHONE

async def handle_phone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка телефона"""
    text = update.message.text
    
    if text == "⏭️ Пропустить":
        context.user_data['phone'] = None
        message = "📞 Телефон пропущен\n\n📧 *Email адрес:*\n(example@gmail.com)"
    else:
        context.user_data['phone'] = text
        message = f"✅ Телефон сохранен\n\n📧 *Email адрес:*\n(example@gmail.com)"
    
    await update.message.reply_text(
        message,
        parse_mode='Markdown',
        reply_markup=create_keyboard()
    )
    return EMAIL

async def handle_email(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка email"""
    text = update.message.text
    
    if text == "⏭️ Пропустить":
        context.user_data['email'] = None
        message = "✉️ Email пропущен\n\n🌐 *Социальные сети:*\n(VK: ссылка, Telegram: @username)"
    else:
        context.user_data['email'] = text
        message = f"✅ Email сохранен\n\n🌐 *Социальные сети:*\n(VK: ссылка, Telegram: @username)"
    
    await update.message.reply_text(
        message,
        parse_mode='Markdown',
        reply_markup=create_keyboard()
    )
    return SOCIAL_MEDIA

async def handle_social_media(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка социальных сетей"""
    text = update.message.text
    
    if text == "⏭️ Пропустить":
        context.user_data['social_media'] = None
        message = "📱 Соцсети пропущены\n\n👨‍👩‍👧 *Родители/Опекуны:*\n(Имена, контакты)"
    else:
        context.user_data['social_media'] = text
        message = f"✅ Соцсети сохранены\n\n👨‍👩‍👧 *Родители/Опекуны:*\n(Имена, контакты)"
    
    await update.message.reply_text(
        message,
        parse_mode='Markdown',
        reply_markup=create_keyboard()
    )
    return PARENTS

async def handle_parents(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка информации о родителях"""
    text = update.message.text
    
    if text == "⏭️ Пропустить":
        context.user_data['parents'] = None
        message = "👪 Родители пропущены\n\n👥 *Друзья/Знакомые:*\n(Имена, как связаны)"
    else:
        context.user_data['parents'] = text
        message = f"✅ Информация о родителях сохранена\n\n👥 *Друзья/Знакомые:*\n(Имена, как связаны)"
    
    await update.message.reply_text(
        message,
        parse_mode='Markdown',
        reply_markup=create_keyboard()
    )
    return FRIENDS

async def handle_friends(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка информации о друзьях"""
    text = update.message.text
    
    if text == "⏭️ Пропустить":
        context.user_data['friends'] = None
        message = "👥 Друзья пропущены\n\n📝 *Дополнительные заметки:*\n(Хобби, интересы, другая информация)"
    else:
        context.user_data['friends'] = text
        message = f"✅ Информация о друзьях сохранена\n\n📝 *Дополнительные заметки:*\n(Хобби, интересы, другая информация)"
    
    await update.message.reply_text(
        message,
        parse_mode='Markdown',
        reply_markup=create_keyboard()
    )
    return NOTES

async def handle_notes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка заметок"""
    text = update.message.text
    
    if text == "⏭️ Пропустить":
        context.user_data['notes'] = None
    else:
        context.user_data['notes'] = text
    
    
    return await generate_dossier(update, context)

def create_html_dossier(user_data, user_id):
    """Создает HTML файл досье с хакерским дизайном"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"dossier_{user_id}_{timestamp}.html"
    filepath = os.path.join(DOSSIER_FOLDER, filename)
    
    
    def fmt(value):
        if value is None or value == "":
            return "<span style='color: #ff5555; font-style: italic;'>[ДАННЫЕ ЗАШИФРОВАНЫ]</span>"
        return escape(str(value))
    
   
    html_content = f"""<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TMD DOSSIER // ID: {user_id}</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {{
            --neon-green: #00ff41;
            --matrix-green: #00cc33;
            --cyber-blue: #0088ff;
            --neon-purple: #9d00ff;
            --dark-bg: #0a0a0a;
        }}
        
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            background-color: var(--dark-bg);
            color: var(--neon-green);
            font-family: 'Courier New', monospace;
            overflow-x: hidden;
            min-height: 100vh;
            position: relative;
        }}
        
        .cyber-container {{
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
            position: relative;
        }}
        
        .cyber-container::before {{
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 3px;
            background: linear-gradient(90deg, transparent, var(--neon-green), transparent);
            animation: scanline 3s linear infinite;
            z-index: 1000;
        }}
        
        @keyframes scanline {{
            0% {{ transform: translateX(-100%); }}
            100% {{ transform: translateX(100%); }}
        }}
        
        .cyber-header {{
            background: rgba(0, 20, 0, 0.8);
            border: 2px solid var(--neon-green);
            padding: 30px;
            margin-bottom: 30px;
            position: relative;
            overflow: hidden;
            box-shadow: 0 0 30px rgba(0, 255, 65, 0.3);
            text-transform: uppercase;
        }}
        
        .hack-title {{
            font-size: 3.5rem;
            text-align: center;
            color: var(--neon-green);
            text-shadow: 0 0 10px var(--neon-green);
            letter-spacing: 5px;
            margin-bottom: 15px;
            animation: glitch 3s infinite;
        }}
        
        @keyframes glitch {{
            0%, 100% {{ transform: translateX(0); opacity: 1; }}
            95% {{ transform: translateX(0); opacity: 1; }}
            96% {{ transform: translateX(-2px); opacity: 0.8; }}
            97% {{ transform: translateX(2px); opacity: 0.8; }}
            98% {{ transform: translateX(-2px); opacity: 0.9; }}
            99% {{ transform: translateX(2px); opacity: 0.9; }}
        }}
        
        .subtitle {{
            text-align: center;
            color: var(--cyber-blue);
            font-size: 1.2rem;
            letter-spacing: 3px;
            margin-bottom: 20px;
        }}
        
        .status-bar {{
            display: flex;
            justify-content: space-between;
            background: rgba(0, 10, 0, 0.9);
            padding: 15px;
            border: 1px solid var(--matrix-green);
            margin-top: 20px;
            flex-wrap: wrap;
            gap: 15px;
        }}
        
        .status-item {{
            display: flex;
            align-items: center;
            gap: 10px;
        }}
        
        .status-led {{
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: var(--neon-green);
            box-shadow: 0 0 10px var(--neon-green);
            animation: pulse 2s infinite;
        }}
        
        @keyframes pulse {{
            0%, 100% {{ opacity: 1; }}
            50% {{ opacity: 0.5; }}
        }}
        
        .data-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }}
        
        .data-card {{
            background: rgba(0, 15, 5, 0.8);
            border: 1px solid rgba(0, 255, 65, 0.3);
            padding: 25px;
            position: relative;
            transition: all 0.3s ease;
            overflow: hidden;
        }}
        
        .data-card:hover {{
            border-color: var(--neon-green);
            box-shadow: 0 0 25px rgba(0, 255, 65, 0.4);
            transform: translateY(-5px);
        }}
        
        .card-header {{
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid rgba(0, 255, 65, 0.2);
        }}
        
        .card-icon {{
            font-size: 1.8rem;
            color: var(--neon-green);
            text-shadow: 0 0 10px currentColor;
        }}
        
        .card-title {{
            font-size: 1.4rem;
            color: var(--cyber-blue);
            text-transform: uppercase;
            letter-spacing: 2px;
        }}
        
        .data-field {{
            margin-bottom: 15px;
            padding: 10px;
            background: rgba(0, 10, 0, 0.5);
            border-left: 3px solid var(--matrix-green);
        }}
        
        .field-label {{
            color: #00cc88;
            font-size: 0.9rem;
            margin-bottom: 5px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }}
        
        .field-value {{
            color: white;
            font-size: 1.1rem;
            padding: 8px 0;
            word-break: break-word;
        }}
        
        .critical-card {{
            border-color: var(--neon-purple);
            background: rgba(157, 0, 255, 0.05);
        }}
        
        .critical-card:hover {{
            box-shadow: 0 0 30px rgba(157, 0, 255, 0.5);
        }}
        
        .terminal-section {{
            background: rgba(0, 20, 0, 0.95);
            border: 2px solid var(--matrix-green);
            padding: 30px;
            margin-bottom: 40px;
            font-family: 'Courier New', monospace;
        }}
        
        .terminal-header {{
            background: rgba(0, 30, 0, 0.9);
            padding: 15px;
            border-bottom: 1px solid var(--neon-green);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}
        
        .terminal-title {{
            color: var(--neon-green);
            font-size: 1.2rem;
        }}
        
        .terminal-content {{
            padding: 20px;
            min-height: 150px;
        }}
        
        .terminal-line {{
            margin-bottom: 10px;
            opacity: 0;
            animation: typeIn 0.5s forwards;
        }}
        
        @keyframes typeIn {{
            to {{ opacity: 1; }}
        }}
        
        .terminal-line:nth-child(1) {{ animation-delay: 0.5s; }}
        .terminal-line:nth-child(2) {{ animation-delay: 1s; }}
        .terminal-line:nth-child(3) {{ animation-delay: 1.5s; }}
        .terminal-line:nth-child(4) {{ animation-delay: 2s; }}
        
        .prompt {{ color: var(--neon-green); }}
        .command {{ color: var(--cyber-blue); }}
        .output {{ color: white; }}
        
        .cyber-footer {{
            background: rgba(0, 20, 0, 0.9);
            border-top: 2px solid var(--neon-green);
            padding: 30px;
            text-align: center;
            margin-top: 50px;
        }}
        
        .access-level {{
            font-size: 1.5rem;
            color: var(--neon-green);
            margin-bottom: 20px;
        }}
        
        .encryption-badge {{
            display: inline-block;
            padding: 10px 20px;
            background: rgba(0, 255, 65, 0.1);
            border: 1px solid var(--neon-green);
            margin: 10px;
            font-size: 0.9rem;
        }}
        
        .blinking-cursor {{
            animation: blink 1s infinite;
            color: var(--neon-green);
        }}
        
        @keyframes blink {{
            0%, 50% {{ opacity: 1; }}
            51%, 100% {{ opacity: 0; }}
        }}
        
        @media (max-width: 768px) {{
            .hack-title {{
                font-size: 2rem;
                letter-spacing: 3px;
            }}
            
            .data-grid {{
                grid-template-columns: 1fr;
            }}
            
            .status-bar {{
                flex-direction: column;
            }}
        }}
        
        ::-webkit-scrollbar {{
            width: 12px;
        }}
        
        ::-webkit-scrollbar-track {{
            background: rgba(0, 20, 0, 0.8);
            border: 1px solid rgba(0, 255, 65, 0.3);
        }}
        
        ::-webkit-scrollbar-thumb {{
            background: linear-gradient(45deg, var(--neon-green), var(--cyber-blue));
        }}
    </style>
</head>
<body>
    <div class="cyber-container">
        <header class="cyber-header">
            <h1 class="hack-title">DOSSIER</h1>
            <p class="subtitle">// DATA RETRIEVAL COMPLETE // ACCESS LEVEL: <span class="blinking-cursor">████</span></p>
            
            <div class="status-bar">
                <div class="status-item">
                    <div class="status-led"></div>
                    <span>SYSTEM: <span style="color: var(--neon-green);">ONLINE</span></span>
                </div>
                <div class="status-item">
                    <div class="status-led" style="background: var(--cyber-blue);"></div>
                    <span>ENCRYPTION: <span style="color: var(--cyber-blue);">ACTIVE</span></span>
                </div>
                <div class="status-item">
                    <div class="status-led" style="background: var(--neon-purple);"></div>
                    <span>CLASS: <span style="color: var(--neon-purple);">RESTRICTED</span></span>
                </div>
                <div class="status-item">
                    <span>ID: <span style="color: white;">{user_id}</span></span>
                </div>
            </div>
        </header>
        
        <main class="data-grid">
            <div class="data-card">
                <div class="card-header">
                    <i class="fas fa-user-secret card-icon"></i>
                    <h2 class="card-title">IDENTITY PROFILE</h2>
                </div>
                <div class="data-field">
                    <div class="field-label">FULL NAME</div>
                    <div class="field-value">{fmt(user_data.get('full_name'))}</div>
                </div>
                <div class="data-field">
                    <div class="field-label">DATE OF BIRTH</div>
                    <div class="field-value">{fmt(user_data.get('birth_date'))}</div>
                </div>
                <div class="data-field">
                    <div class="field-label">BIRTH PLACE</div>
                    <div class="field-value">{fmt(user_data.get('birth_place'))}</div>
                </div>
            </div>
            
            <div class="data-card">
                <div class="card-header">
                    <i class="fas fa-map-marked-alt card-icon"></i>
                    <h2 class="card-title">GEO-LOCATION DATA</h2>
                </div>
                <div class="data-field">
                    <div class="field-label">ADDRESS</div>
                    <div class="field-value">{fmt(user_data.get('address'))}</div>
                </div>
                <div class="data-field">
                    <div class="field-label">REGION</div>
                    <div class="field-value">{fmt(user_data.get('region'))}</div>
                </div>
                <div class="data-field">
                    <div class="field-label">COUNTRY</div>
                    <div class="field-value">{fmt(user_data.get('country'))}</div>
                </div>
            </div>
            
            <div class="data-card">
                <div class="card-header">
                    <i class="fas fa-graduation-cap card-icon"></i>
                    <h2 class="card-title">EDUCATION RECORDS</h2>
                </div>
                <div class="data-field">
                    <div class="field-label">EDUCATION LEVEL</div>
                    <div class="field-value">{fmt(user_data.get('education'))}</div>
                </div>
                <div class="data-field">
                    <div class="field-label">INSTITUTION</div>
                    <div class="field-value">{fmt(user_data.get('school'))}</div>
                </div>
                <div class="data-field">
                    <div class="field-label">GRADUATION YEAR</div>
                    <div class="field-value">{fmt(user_data.get('graduation_year'))}</div>
                </div>
            </div>
            
            <div class="data-card critical-card">
                <div class="card-header">
                    <i class="fas fa-satellite-dish card-icon"></i>
                    <h2 class="card-title">COMMUNICATION CHANNELS</h2>
                </div>
                <div class="data-field">
                    <div class="field-label">PHONE NUMBER</div>
                    <div class="field-value">{fmt(user_data.get('phone'))}</div>
                </div>
                <div class="data-field">
                    <div class="field-label">EMAIL ADDRESS</div>
                    <div class="field-value">{fmt(user_data.get('email'))}</div>
                </div>
                <div class="data-field">
                    <div class="field-label">SOCIAL NETWORKS</div>
                    <div class="field-value">{fmt(user_data.get('social_media'))}</div>
                </div>
            </div>
            
            <div class="data-card">
                <div class="card-header">
                    <i class="fas fa-network-wired card-icon"></i>
                    <h2 class="card-title">SOCIAL NETWORK</h2>
                </div>
                <div class="data-field">
                    <div class="field-label">PARENTS/GUARDIANS</div>
                    <div class="field-value">{fmt(user_data.get('parents'))}</div>
                </div>
                <div class="data-field">
                    <div class="field-label">FRIENDS/ASSOCIATES</div>
                    <div class="field-value">{fmt(user_data.get('friends'))}</div>
                </div>
            </div>
            
            <div class="data-card critical-card" style="grid-column: 1 / -1;">
                <div class="card-header">
                    <i class="fas fa-file-alt card-icon"></i>
                    <h2 class="card-title">ADDITIONAL NOTES</h2>
                </div>
                <div class="data-field" style="min-height: 120px; background: rgba(0,0,0,0.5);">
                    <div class="field-value" style="white-space: pre-wrap;">
                        {fmt(user_data.get('notes'))}
                    </div>
                </div>
            </div>
        </main>
        
        <section class="terminal-section">
            <div class="terminal-header">
                <div class="terminal-title">
                    <i class="fas fa-terminal"></i> SYSTEM TERMINAL
                </div>
                <div style="color: var(--matrix-green); font-size: 0.9rem;">
                    {datetime.now().strftime('%d.%m.%Y %H:%M:%S')}
                </div>
            </div>
            <div class="terminal-content">
                <div class="terminal-line">
                    <span class="prompt">root@dossier:~$</span> <span class="command">scan_target --id={user_id}</span>
                </div>
                <div class="terminal-line">
                    <span class="output">[✓] TARGET IDENTIFIED</span>
                </div>
                <div class="terminal-line">
                    <span class="output">[✓] DATA COLLECTION COMPLETE</span>
                </div>
                <div class="terminal-line">
                    <span class="output">[✓] DOSSIER GENERATED</span>
                </div>
                <div class="terminal-line">
                    <span class="prompt">root@dossier:~$</span> <span class="command">system_log --status=success</span>
                </div>
                <div class="terminal-line">
                    <span class="output">[✓] OPERATION COMPLETED</span> <span class="blinking-cursor">_</span>
                </div>
            </div>
        </section>
        
        <footer class="cyber-footer">
            <div class="access-level">
                ACCESS LEVEL: <span style="color: var(--neon-purple);">BETA</span>
            </div>
            <div style="margin: 20px 0;">
                <span class="encryption-badge">
                    <i class="fas fa-shield-alt"></i> QUANTUM ENCRYPTION
                </span>
                <span class="encryption-badge">
                    <i class="fas fa-satellite"></i> SECURE TRANSMISSION
                </span>
                <span class="encryption-badge">
                    <i class="fas fa-user-secret"></i> ANONYMIZED DATA
                </span>
            </div>
            <div style="color: rgba(255,255,255,0.5); font-size: 0.9rem; margin-top: 20px;">
                © {datetime.now().year} Досье создано ботом @dossibot
                <br>
                UNAUTHORIZED ACCESS IS PROHIBITED
            </div>
        </footer>
    </div>
    
    <script>
        // Простая анимация матрицы
        function createMatrixEffect() {{
            const container = document.querySelector('.cyber-container');
            const chars = "01";
            const lines = Math.floor(window.innerHeight / 20);
            
            for(let i = 0; i < lines; i++) {{
                const line = document.createElement('div');
                line.style.position = 'fixed';
                line.style.left = Math.random() * 100 + 'vw';
                line.style.top = '-20px';
                line.style.color = 'rgba(0, 255, 65, 0.1)';
                line.style.fontSize = '14px';
                line.style.fontFamily = 'monospace';
                line.style.zIndex = '-1';
                line.style.whiteSpace = 'nowrap';
                
                let text = '';
                for(let j = 0; j < 50; j++) {{
                    text += chars[Math.floor(Math.random() * chars.length)];
                }}
                line.textContent = text;
                
                container.appendChild(line);
                
                // Анимация падения
                const duration = 3000 + Math.random() * 4000;
                line.animate([
                    {{ transform: 'translateY(-20px)', opacity: 0 }},
                    {{ transform: 'translateY(0)', opacity: 0.3 }},
                    {{ transform: 'translateY(100vh)', opacity: 0 }}
                ], {{
                    duration: duration,
                    delay: Math.random() * 2000,
                    iterations: Infinity
                }});
            }}
        }}
        
        // Глитч эффект при наведении
        document.querySelectorAll('.data-card').forEach(card => {{
            card.addEventListener('mouseenter', () => {{
                card.style.animation = 'none';
                setTimeout(() => {{
                    card.style.animation = 'glitch 0.3s';
                }}, 10);
            }});
        }});
        
        // Запуск при загрузке
        window.addEventListener('load', () => {{
            createMatrixEffect();
            
            // Тайпинг эффект для терминала
            const lines = document.querySelectorAll('.terminal-line');
            lines.forEach((line, index) => {{
                line.style.animationDelay = `${{index * 0.5}}s`;
            }});
        }});
    </script>
</body>
</html>"""
    
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    return filepath, filename

async def generate_dossier(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Генерируем досье и отправляем пользователю"""
    user = update.effective_user
    
   
    await update.message.reply_text(
        "🔥 *Генерирую досье...*\n\n"
        "🖥️ Инициализация системы...\n"
        "🔍 Сканирование данных...\n"
        "💾 Генерация интерфейса...\n"
        "⚡ Создание файла...",
        parse_mode='Markdown',
        reply_markup=None
    )
    

    try:
        filepath, filename = create_html_dossier(context.user_data, user.id)
        
       
        with open(filepath, 'rb') as f:
            await update.message.reply_document(
                document=f,
                filename=filename,
                caption=f"""
🚀 *Досье создано!*

📄 **Файл:** `{filename}`
📊 **Заполнено полей:** {sum(1 for v in context.user_data.values() if v is not None)}/{len(context.user_data)}
🕐 **Время создания:** {datetime.now().strftime('%H:%M:%S')}

💀 *Особенности:*
• Проблем при генерации не найдено
• Пустые элементы зашифрованы
• Весит +- 20КБ

⚠️ *ВАЖНОЕ ПРЕДУПРЕЖДЕНИЕ:*
Этот файл содержит персональные данные.
Используйте только в законных целях с согласия владельца данных.

📁 *Др. команды:*
• /help
• /stats

🔄 Для создания нового досье используйте /start
                """,
                parse_mode='Markdown'
            )
            
        # Сохраняем данные
        user_data = {}
        if os.path.exists(DATA_FILE):
            try:
                with open(DATA_FILE, 'r', encoding='utf-8') as f:
                    user_data = json.load(f)
            except:
                user_data = {}
        
        if str(user.id) not in user_data:
            user_data[str(user.id)] = []
        
        user_data[str(user.id)].append({
            'timestamp': datetime.now().isoformat(),
            'filename': filename,
            'data': {k: v for k, v in context.user_data.items() if v is not None}
        })
        
        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(user_data, f, ensure_ascii=False, indent=2)
            
    except Exception as e:
        logger.error(f"Ошибка создания досье: {e}")
        await update.message.reply_text(
            "💥 *КРИТИЧЕСКАЯ ОШИБКА СИСТЕМЫ*\n\n"
            "Попробуйте еще раз командой /start\n"
            "Если ошибка повторяется, проверьте доступ к диску.",
            parse_mode='Markdown'
        )
    
    # Очищаем данные
    context.user_data.clear()
    
    return ConversationHandler.END

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Отмена диалога"""
    await update.message.reply_text(
        "❌ *Создание досье отменено*\n\n"
        "Все введенные данные удалены.\n"
        "Для начала нового досье используйте /start",
        parse_mode='Markdown',
        reply_markup=None
    )
    context.user_data.clear()
    return ConversationHandler.END

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Помощь"""
    help_text = """
💀 *TMD DOSSIER - Помощь*

*Основные команды:*
/start - Начать создание досье
/help - Показать это сообщение
/cancel - Отменить текущее создание досье
/legal - Правовая информация
/stats - Статистика системы

*Как это работает:*
1. Бот задает вопросы по очереди
2. На каждый вопрос можно ответить или нажать «Пропустить»
3. Все поля необязательные
4. В конце создается файл

*Правовые аспекты:*
• Используйте только с согласия субъекта данных
• Не нарушайте приватность других людей
• Соблюдайте законодательство
    """
    await update.message.reply_text(help_text, parse_mode='Markdown')

async def legal_info(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Правовая информация"""
    legal_text = """
⚡ *ПРАВОВАЯ ИНФОРМАЦИЯ И ПРЕДУПРЕЖДЕНИЕ*

*Этот бот предназначен ТОЛЬКО для:*
✅ Создания личных анкет для себя
✅ Составления семейных родословных (с согласия)
✅ Создания портфолио и резюме
✅ Легальных баз данных

*Категорически ЗАПРЕЩЕНО:*
❌ Собирать данные без согласия человека
❌ Использовать для слежки или преследования
❌ Нарушать приватность
❌ Заниматься мошенничеством

*Юридические последствия:*
• Несоблюдение законов о защите данных - уголовная ответственность
• В РФ действует Федеральный закон №152-ФЗ
• В ЕС — GDPR

*Рекомендации:*
1. Всегда получайте письменное согласие
2. Храните данные в защищенном месте
3. Не распространяйте чужие данные
4. Удаляйте данные по требованию

Бот создан в образовательных целях. Используйте ответственно!
    """
    await update.message.reply_text(legal_text, parse_mode='Markdown')

async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Статистика"""
    try:
        if os.path.exists(DATA_FILE):
            with open(DATA_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            total_users = len(data)
            total_dossiers = sum(len(dossiers) for dossiers in data.values())
            
            stats_text = f"""
💻 *СТАТИСТИКА*

👥 Всего пользователей: *{total_users}*
📁 Всего создано досье: *{total_dossiers}*
📅 Система работает с: *{(datetime.now().date())}*

*Техническая информация:*
• Формат: HTML с CSS3 анимациями
• Кодировка: UTF-8

*Безопасность:*
🔐 Локальное хранение данных
🗑️ Удаление по запросу
📜 Соблюдение 152-ФЗ
            """
        else:
            stats_text = "📊 Статистика пока недоступна. Досье еще не создавались."
        
        await update.message.reply_text(stats_text, parse_mode='Markdown')
    except Exception as e:
        logger.error(f"Ошибка статистики: {e}")
        await update.message.reply_text("💥 Ошибка получения статистики.")

def main():
    """Запуск бота"""
    # Создаем папки
    ensure_folders()
    
    # Создаем Application
    application = Application.builder().token(TOKEN).build()
    
    # Создаем ConversationHandler
    conv_handler = ConversationHandler(
        entry_points=[CommandHandler('start', start)],
        states={
            FULL_NAME: [MessageHandler(filters.TEXT, handle_full_name)],
            BIRTH_DATE: [MessageHandler(filters.TEXT, handle_birth_date)],
            BIRTH_PLACE: [MessageHandler(filters.TEXT, handle_birth_place)],
            ADDRESS: [MessageHandler(filters.TEXT, handle_address)],
            REGION: [MessageHandler(filters.TEXT, handle_region)],
            COUNTRY: [MessageHandler(filters.TEXT, handle_country)],
            EDUCATION: [MessageHandler(filters.TEXT, handle_education)],
            SCHOOL: [MessageHandler(filters.TEXT, handle_school)],
            GRADUATION_YEAR: [MessageHandler(filters.TEXT, handle_graduation_year)],
            PHONE: [MessageHandler(filters.TEXT, handle_phone)],
            EMAIL: [MessageHandler(filters.TEXT, handle_email)],
            SOCIAL_MEDIA: [MessageHandler(filters.TEXT, handle_social_media)],
            PARENTS: [MessageHandler(filters.TEXT, handle_parents)],
            FRIENDS: [MessageHandler(filters.TEXT, handle_friends)],
            NOTES: [MessageHandler(filters.TEXT, handle_notes)],
        },
        fallbacks=[CommandHandler('cancel', cancel)]
    )
    
    # Добавляем handlers
    application.add_handler(conv_handler)
    application.add_handler(CommandHandler('help', help_command))
    application.add_handler(CommandHandler('legal', legal_info))
    application.add_handler(CommandHandler('stats', stats_command))
    
 
    print("\n" + "="*50)
    print("💀 BOT ЗАПУЩЕН!")
    print("📁 Папка для досье:", DOSSIER_FOLDER)
    print("📊 Файл данных:", DATA_FILE)
    print("="*50 + "\n")
    
  
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()

class Config:
    # Основные настройки
    BOT_TOKEN = "82469198:ATnZfAoJSSoKYnEJHy-fU2sR-WaoBvBE0"
    
    # Пути
    DOSSIER_FOLDER = "dossiers"
    DATA_FILE = "user_data.json"
    LOG_FILE = "bot.log"
    
    # Настройки безопасности
    MAX_FILE_SIZE_MB = 10
    ALLOWED_EXTENSIONS = ['.html']
    
    # Лимиты
    MAX_DOSSIERS_PER_USER = 100
    MAX_FIELD_LENGTH = 1000
    
    # Время хранения (в днях)
    DATA_RETENTION_DAYS = 365
    
    # Настройки HTML
    HTML_TEMPLATE = "template.html"
    AUTO_DELETE_HTML_DAYS = 30

# Цвета для логов
class Colors:
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BLUE = '\033[94m'
    END = '\033[0m' 
